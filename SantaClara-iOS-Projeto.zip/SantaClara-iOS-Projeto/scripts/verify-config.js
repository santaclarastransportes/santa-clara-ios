const fs = require('fs');
const cfg = JSON.parse(fs.readFileSync('capacitor.config.json', 'utf8'));
if (!cfg.appId || !cfg.appName || !cfg.server?.url) {
  console.error('Configuração Capacitor incompleta.');
  process.exit(1);
}
console.log(`Configuração OK: ${cfg.appName} -> ${cfg.server.url}`);
console.log('Nota: este comando valida a configuração; não compila nem assina um IPA.');
