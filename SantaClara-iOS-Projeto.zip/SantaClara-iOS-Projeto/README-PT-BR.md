# Santa Clara Transportes — projeto-base iOS

Este projeto é um **ponto de partida**, não um IPA pronto. Ele usa Capacitor e está configurado para carregar a Central Santa Clara existente:

https://santaclarastransportes.github.io/Santa-Clara-Transportes-Virtual/

## O que já está configurado
- Nome do app: Santa Clara Transportes
- Identificador iOS inicial: `br.com.santaclara.transportes`
- Endereço HTTPS do site oficial
- Estrutura web mínima de contingência
- Dependências do Capacitor para gerar o projeto iOS

## Importante
- Não há arquivo `.ipa` neste ZIP.
- Não inclui certificado, perfil de provisionamento, credenciais Apple ou segredos Firebase.
- O site continua sendo carregado pela internet; isto não transforma o site em um app totalmente offline.
- A autenticação, o Firebase e as funções existentes continuam dependendo do próprio site.
- O identificador `br.com.santaclara.transportes` deve ser confirmado como disponível/adequado antes da distribuição.

## Próximos passos
1. Extraia o ZIP e envie estes arquivos para um repositório GitHub.
2. Em um ambiente com Node.js, execute `npm install`.
3. Execute `npx cap add ios` e depois `npx cap sync ios`.
4. Abra/compile a pasta iOS em um serviço de build macOS na nuvem.
5. Para instalar em iPhones, configure assinatura e provisionamento Apple compatíveis com o método de distribuição.

## Sobre instalar diretamente
Enviar um `.ipa` por WhatsApp ou baixá-lo no iPhone não basta para instalá-lo. O pacote precisa estar assinado e distribuído por um método aceito pelo iOS. Sem uma conta paga Apple Developer, as opções são limitadas; a distribuição pública e o TestFlight normalmente exigem a adesão paga.

## Alternativa gratuita imediata
No iPhone, abra a Central no Safari, toque em **Compartilhar** e escolha **Adicionar à Tela de Início**. Isso cria um ícone para acessar o site, mas não gera um IPA.
